this.devices = {
desktop: {
                deviceName: "desktop",
                size: "1384x1000"
},
};

forAll(devices, function (device) {
test("Manage Military information", function (device) {
var driver = createDriver("http://vcm-web.s3-website-us-east-1.amazonaws.com/", device.size); 
Thread.sleep(50000);
// var WebPage = $page("Page Login", {
//                 //login:"//*[@id='loginButton']",
//                 username:"//*[@id='username']",
//                 password:"//*[@id='password']",
//                 submit:"//*[@id='submit-button']",

// });
// var WebPage = new WebPage(driver);
// //WebPage.login.click();
// Thread.sleep(5000);
// WebPage.username.typeText("admin");
// WebPage.password.typeText("admin");
// Thread.sleep(5000);
// WebPage.submit.click();
// Thread.sleep(6000);
/*For Account Details
var AccountPage = $page("Account Click", {
Account:"//*[@id='tableDD']/tbody/tr[2]/td[1]/div[1]/a",

});
var AccountPage = new AccountPage(driver);
AccountPage.Account.click();                     
Thread.sleep(10000);*/
//inject(driver,'$(".container-fluid").hide()');
checkLayout({
            driver: driver,
            spec: "D:/PixelPerfect/VCM_backup/Customer Management Module/Retesting/Military Information/Customer_Management_Screen5.gspec",
            tags:[device.deviceName],
});
});
});
